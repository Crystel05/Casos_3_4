package Networking.ServerSide;

public class ServerStart {
    public static void main(String[] args) {
        new Server(7800);
    }
}
