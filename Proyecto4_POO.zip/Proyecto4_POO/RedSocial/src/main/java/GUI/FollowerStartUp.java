package GUI;

public class FollowerStartUp {
    public static void main(String[] args) {
        new PantallaSeguidor().setVisible(true);
    }
}
