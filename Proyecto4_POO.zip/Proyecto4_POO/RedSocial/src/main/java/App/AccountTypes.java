package App;

public enum AccountTypes {
    FOLLOWER,
    CELEBRITY
}
