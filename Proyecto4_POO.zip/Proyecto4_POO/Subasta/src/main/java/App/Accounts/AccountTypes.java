package App.Accounts;

public enum AccountTypes {
    BUYER,
    AUCTIONEER
}
