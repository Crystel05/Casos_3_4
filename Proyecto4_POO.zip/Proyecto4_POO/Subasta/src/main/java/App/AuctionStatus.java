
package App;


 public enum AuctionStatus {

    ACTIVE,
    CANCELLED,
     CLOSED
    
}
