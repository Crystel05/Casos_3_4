package GUI;

public class BuyerStart {
    public static void main(String[] args) {
        new PantallaOferente().setVisible(true);
    }
}
