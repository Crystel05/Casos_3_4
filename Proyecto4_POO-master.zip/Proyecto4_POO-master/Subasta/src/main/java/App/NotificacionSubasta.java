package Subastas;

import Observer.Notification;

public class NotificacionSubasta extends Notification {

    NotificacionSubasta(){

    }

}

