package Subastas;

import java.util.ArrayList;

public class CasaDeSubastas {

    ArrayList<Subasta> subastas;


}
