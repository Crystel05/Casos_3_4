package Subastas;

public class Oferente {
}
