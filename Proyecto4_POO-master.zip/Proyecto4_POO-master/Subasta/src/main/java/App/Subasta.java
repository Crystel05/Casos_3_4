package Subastas;

import Observer.IObserver;

public class Subasta {

    Subastador subastador;
    String articulo;
    int tope;
    IObserver mejorPuja;



}
