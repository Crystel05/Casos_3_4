package RedSocial;

import Observer.Notification;

public class NotificacionSocial extends Notification {

    public NotificacionSocial(){

    }

}
