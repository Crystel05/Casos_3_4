package RedSocial;

public class Seguidor {
}
